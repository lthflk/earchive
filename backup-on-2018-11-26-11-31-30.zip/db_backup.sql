#
# TABLE STRUCTURE FOR: data_arsip
#

DROP TABLE IF EXISTS `data_arsip`;

CREATE TABLE `data_arsip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noarsip` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pencipta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_pengolah` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `uraian` text COLLATE utf8_unicode_ci NOT NULL,
  `ket` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `jenisdok` int(2) NOT NULL COMMENT '1 = Biasa, 2 = Rahasia',
  `kode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nobox` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `lokasi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lantai` int(254) NOT NULL,
  `ruangan` int(254) NOT NULL,
  `lemari` int(254) NOT NULL,
  `baris` int(254) NOT NULL,
  `media` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` text COLLATE utf8_unicode_ci,
  `tgl_input` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tgl_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dep` int(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `noarsip` (`noarsip`),
  KEY `pencipta` (`pencipta`),
  KEY `unit_pengolah` (`unit_pengolah`),
  FULLTEXT KEY `uraian` (`uraian`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `data_arsip` (`id`, `noarsip`, `pencipta`, `unit_pengolah`, `tanggal`, `uraian`, `ket`, `jenisdok`, `kode`, `jumlah`, `nobox`, `lokasi`, `lantai`, `ruangan`, `lemari`, `baris`, `media`, `file`, `tgl_input`, `tgl_update`, `username`, `dep`) VALUES (1, 1, 3, 8, 2018-11-17, -, asli, 1, 32, 1, 21, 1, 36, 18, 36, 29, 5, , 2018-11-26 00:04:32, 0000-00-00 00:00:00, admin, 3);
INSERT INTO `data_arsip` (`id`, `noarsip`, `pencipta`, `unit_pengolah`, `tanggal`, `uraian`, `ket`, `jenisdok`, `kode`, `jumlah`, `nobox`, `lokasi`, `lantai`, `ruangan`, `lemari`, `baris`, `media`, `file`, `tgl_input`, `tgl_update`, `username`, `dep`) VALUES (2, 2, 3, 7, 2018-11-17, -, asli, 1, 5, 1, 231, 1, 36, 19, 27, 33, 5, 2__Halaman_Pengesahan.pdf, 2018-11-26 00:04:32, 2018-11-26 15:59:58, admin, 1);
INSERT INTO `data_arsip` (`id`, `noarsip`, `pencipta`, `unit_pengolah`, `tanggal`, `uraian`, `ket`, `jenisdok`, `kode`, `jumlah`, `nobox`, `lokasi`, `lantai`, `ruangan`, `lemari`, `baris`, `media`, `file`, `tgl_input`, `tgl_update`, `username`, `dep`) VALUES (3, 3, 8, 6, 2018-11-17, -, asli, 2, 33, 1, 452, 1, 36, 19, 27, 32, 5, , 2018-11-26 00:04:33, 0000-00-00 00:00:00, admin, 2);


#
# TABLE STRUCTURE FOR: master_baris
#

DROP TABLE IF EXISTS `master_baris`;

CREATE TABLE `master_baris` (
  `id_baris` int(254) NOT NULL AUTO_INCREMENT,
  `id_lemari` int(254) NOT NULL,
  `no_baris` int(254) NOT NULL,
  PRIMARY KEY (`id_baris`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (24, 32, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (25, 32, 2);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (26, 33, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (27, 33, 2);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (28, 36, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (29, 36, 2);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (30, 37, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (31, 37, 2);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (32, 27, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (33, 27, 2);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (34, 40, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (35, 41, 1);
INSERT INTO `master_baris` (`id_baris`, `id_lemari`, `no_baris`) VALUES (36, 29, 1);


#
# TABLE STRUCTURE FOR: master_departemen
#

DROP TABLE IF EXISTS `master_departemen`;

CREATE TABLE `master_departemen` (
  `id_dep` int(12) NOT NULL AUTO_INCREMENT,
  `kode_dep` varchar(30) NOT NULL,
  `nama_dep` varchar(254) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_dep`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_departemen` (`id_dep`, `kode_dep`, `nama_dep`, `keterangan`) VALUES (1, SDM, Sumber Daya Manusia, kosongkan aja);
INSERT INTO `master_departemen` (`id_dep`, `kode_dep`, `nama_dep`, `keterangan`) VALUES (2, OPR, Operasional, );
INSERT INTO `master_departemen` (`id_dep`, `kode_dep`, `nama_dep`, `keterangan`) VALUES (3, UMM, Umum, );


#
# TABLE STRUCTURE FOR: master_kode
#

DROP TABLE IF EXISTS `master_kode`;

CREATE TABLE `master_kode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `retensi` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode` (`kode`),
  KEY `nama` (`nama`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (5, SDM.01, Rekrutmen Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (6, SDM.02, Mutasi Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (7, SDM.03, Pengembangan Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (8, SDM.04, Cuti Pegawai, 3);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (9, SDM.03.01, Pelatihan Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (10, SDM.03.02, Beasiswa Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (11, SDM.01.01, Pengangakatan Pegawai, 1);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (12, SDM.05, Pemberhentian Pegawai, 5);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (13, KEU.01, Rencana Anggaran, 10);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (14, KEU.02, Realisasi Anggaran Pegawai, 10);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (15, KEU.03, Realisasi Anggaran Umum dan Rumah Tangga, 10);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (16, HKP.01, Peraturan Perusahaan, 3);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (17, HKP.01.01, Peraturan Direksi Perusahaan, 5);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (18, HKP.01.02, Keputusan Direksi Perusahaan, 20);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (19, HKP.02, Pengawasan Internal, 10);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (20, RND.01, Penelitian dan Pengembangan, 3);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (21, UMUM.01, Inventarisasi Barang Bergerak, 5);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (22, UMUM.02, Inventarisasi Barang Tidak Bergerak, 5);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (27, ZZZ, Zzzz, 0);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (28, ZZZ.01, Z01, 0);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (32, U.01, , 0);
INSERT INTO `master_kode` (`id`, `kode`, `nama`, `retensi`) VALUES (33, O.01, , 0);


#
# TABLE STRUCTURE FOR: master_lantai
#

DROP TABLE IF EXISTS `master_lantai`;

CREATE TABLE `master_lantai` (
  `id_lantai` int(254) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `no_lantai` int(254) NOT NULL,
  PRIMARY KEY (`id_lantai`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (36, 1, 1);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (37, 1, 2);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (38, 1, 3);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (39, 6, 1);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (40, 6, 2);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (41, 0, 0);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (42, 2, 1);
INSERT INTO `master_lantai` (`id_lantai`, `id`, `no_lantai`) VALUES (43, 2, 2);


#
# TABLE STRUCTURE FOR: master_lemari
#

DROP TABLE IF EXISTS `master_lemari`;

CREATE TABLE `master_lemari` (
  `id_lemari` int(254) NOT NULL AUTO_INCREMENT,
  `id_ruangan` int(254) NOT NULL,
  `no_lemari` int(254) NOT NULL,
  PRIMARY KEY (`id_lemari`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (24, 20, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (25, 20, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (26, 20, 3);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (27, 19, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (28, 19, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (29, 21, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (30, 21, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (32, 23, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (33, 23, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (34, 24, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (35, 24, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (36, 18, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (37, 18, 2);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (39, 0, 0);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (40, 26, 1);
INSERT INTO `master_lemari` (`id_lemari`, `id_ruangan`, `no_lemari`) VALUES (41, 22, 1);


#
# TABLE STRUCTURE FOR: master_lokasi
#

DROP TABLE IF EXISTS `master_lokasi`;

CREATE TABLE `master_lokasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lokasi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_lokasi` (`nama_lokasi`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (1, Gedung A, Unit II1);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (2, Gedung B, Unit III);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (3, Gedung C, Unit IV);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (4, Lokasi);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (5, Gedung C lt 2);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (6, Gedung B lt4);
INSERT INTO `master_lokasi` (`id`, `nama_lokasi`) VALUES (14, Gedung A, Unit II);


#
# TABLE STRUCTURE FOR: master_media
#

DROP TABLE IF EXISTS `master_media`;

CREATE TABLE `master_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_media` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_media` (`nama_media`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_media` (`id`, `nama_media`) VALUES (5, Audio Cassette);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (6, Audio Disc);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (4, Blueprint);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (3, Kartografi);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (2, Tekstual);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (7, Video Cartridge);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (8, Digital);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (9, Media);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (10, kertas koran);
INSERT INTO `master_media` (`id`, `nama_media`) VALUES (12, usb);


#
# TABLE STRUCTURE FOR: master_pencipta
#

DROP TABLE IF EXISTS `master_pencipta`;

CREATE TABLE `master_pencipta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pencipta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_pencipta` (`nama_pencipta`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (5, Bidang Hukum dan Tata Laksana);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (3, Bidang Kepegawaian);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (6, Bidang Keuangan);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (4, Bidang Pengadaan);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (8, Bidang Produksi);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (7, Bidang Umum dan Rumah Tangga);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (9, Pencipta);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (10, Bidang ZZZ);
INSERT INTO `master_pencipta` (`id`, `nama_pencipta`) VALUES (11, Bidang QWE);


#
# TABLE STRUCTURE FOR: master_pengolah
#

DROP TABLE IF EXISTS `master_pengolah`;

CREATE TABLE `master_pengolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengolah` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_pengolah` (`nama_pengolah`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (1, Unit Arsip Teknologi Informasi);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (4, Unit Arsip Sekretariat Hukum dan Tata Laksana);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (2, Unit Arsip Kepegawaian);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (5, Unit Arsip Pengadaan);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (6, Unit Arsip Biro Umum dan Rumah Tangga);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (3, Unit Kearsipan Pusat);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (7, Pengolah);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (8, unit ABC);
INSERT INTO `master_pengolah` (`id`, `nama_pengolah`) VALUES (9, Unit SDF);


#
# TABLE STRUCTURE FOR: master_ruangan
#

DROP TABLE IF EXISTS `master_ruangan`;

CREATE TABLE `master_ruangan` (
  `id_ruangan` int(254) NOT NULL AUTO_INCREMENT,
  `id_lantai` int(254) NOT NULL,
  `nama_ruangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id_ruangan`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (18, 36, Ruangan A);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (19, 36, Ruangan B);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (20, 36, Ruangan C);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (21, 39, Ruangan A);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (22, 39, Ruangan B);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (23, 40, Ruangan A);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (24, 40, Ruangan B);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (25, 0, Ruangan);
INSERT INTO `master_ruangan` (`id_ruangan`, `id_lantai`, `nama_ruangan`) VALUES (26, 43, Ruangan Gue nih);


#
# TABLE STRUCTURE FOR: master_user
#

DROP TABLE IF EXISTS `master_user`;

CREATE TABLE `master_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','disable') COLLATE utf8_unicode_ci NOT NULL,
  `tipe` enum('admin','user','sumin') COLLATE utf8_unicode_ci NOT NULL,
  `akses_klas` text COLLATE utf8_unicode_ci NOT NULL,
  `akses_modul` text COLLATE utf8_unicode_ci NOT NULL,
  `depar` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (1, admin, $2y$10$M57KBHBtl9HsFQP6rxrqUOuSqO/MiQJnTqTu4wM5OlWwa/lTKyb2S, active, sumin, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on","backupdb":"on","departemen":"on"}, 2);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (6, user, $2y$10$uE3PKQ/tWOoGQwnfKXVYjOXHRHQ43o5PgYpN2wf2lp.iI4.DFshoq, active, user, , {"entridata":"on","sirkulasi":"on"}, 2);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (7, deni, $2y$10$uRX3lo8tB2ogPMJA2HwpQe.WGOgemzEM17hL5mrtMsFRo516HnKwW, active, admin, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on","departemen":"on"}, 1);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (8, gustian, $2y$10$Av2uvzHlIhL4ga2nz5ZAS.NJBxKuawbGMTpP/1MLyRAZJ/KoOzp2i, active, user, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on"}, 2);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (19, agus, $2y$10$8NnSBOxztydlJ1OXUYi2hOkl3ZB24gX8W9ULSLRQvX6CKMI8ZIFT., disable, user, hkp,keu, {"media":"on"}, 2);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (20, kamal, $2y$10$GjfR2Izxse0th0dJ/JMqfOD.Ro6gVHIQnmKdCODVO7jGR58rxDPQ2, disable, admin, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on"}, 3);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (23, yuki, $2y$10$ICcgQ74zmigB009Fz/ZcM.32DjUgVQIdnUEZsrwxdJ6T0cwUT1Kyi, active, user, , null, 1);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (24, luthfi, $2y$10$7xKVWsN9ykLJhtM3Eh3//Olx/wkRHgCLpMwKO.I6YLz9uKPaUavDa, active, admin, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on","departemen":"on"}, 1);
INSERT INTO `master_user` (`id`, `username`, `password`, `status`, `tipe`, `akses_klas`, `akses_modul`, `depar`) VALUES (34, bego, $2y$10$oJWTF396OCZ31Xb1lvDat.AxtSRB9yCEWZnTjHWstr30qUcKkGStu, active, sumin, , {"entridata":"on","sirkulasi":"on","klasifikasi":"on","pencipta":"on","pengolah":"on","lokasi":"on","media":"on","user":"on","import":"on","backupdb":"on","departemen":"on"}, 2);


#
# TABLE STRUCTURE FOR: sirkulasi
#

DROP TABLE IF EXISTS `sirkulasi`;

CREATE TABLE `sirkulasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noarsip` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username_peminjam` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keperluan` text COLLATE utf8_unicode_ci,
  `tgl_pinjam` datetime NOT NULL,
  `tgl_haruskembali` datetime NOT NULL,
  `tgl_pengembalian` datetime DEFAULT NULL,
  `tgl_transaksi` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `noarsip` (`noarsip`),
  KEY `username_peminjam` (`username_peminjam`),
  KEY `tgl_pinjam` (`tgl_pinjam`),
  KEY `tgl_pengembalian` (`tgl_pengembalian`),
  KEY `tgl_haruskembali` (`tgl_haruskembali`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `sirkulasi` (`id`, `noarsip`, `username_peminjam`, `keperluan`, `tgl_pinjam`, `tgl_haruskembali`, `tgl_pengembalian`, `tgl_transaksi`) VALUES (15, 123, user, gak ada bosss, 2018-11-20 00:00:00, 2018-11-22 00:00:00, 2018-11-20 20:56:06, 2018-11-20 12:50:07);
INSERT INTO `sirkulasi` (`id`, `noarsip`, `username_peminjam`, `keperluan`, `tgl_pinjam`, `tgl_haruskembali`, `tgl_pengembalian`, `tgl_transaksi`) VALUES (20, ABC01, gustian, etah lah, 2018-11-21 00:00:00, 2018-11-22 00:00:00, NULL, 2018-11-21 21:32:33);
INSERT INTO `sirkulasi` (`id`, `noarsip`, `username_peminjam`, `keperluan`, `tgl_pinjam`, `tgl_haruskembali`, `tgl_pengembalian`, `tgl_transaksi`) VALUES (14, 4567, bebal1, mau makan iya 1, 2018-11-20 00:00:00, 2018-11-26 00:00:00, 2018-11-20 09:22:44, 2018-11-20 09:09:43);


#
# TABLE STRUCTURE FOR: system_log
#

DROP TABLE IF EXISTS `system_log`;

CREATE TABLE `system_log` (
  `id` int(11) NOT NULL,
  `kode_transaksi` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username_transaksi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kode_transaksi` (`kode_transaksi`),
  KEY `username_transaksi` (`username_transaksi`),
  KEY `tgl_transaksi` (`tgl_transaksi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: visitor_file
#

DROP TABLE IF EXISTS `visitor_file`;

CREATE TABLE `visitor_file` (
  `id_visit` int(5) NOT NULL AUTO_INCREMENT,
  `id_file` int(5) NOT NULL,
  `id_user` int(5) NOT NULL,
  `time_visit` date NOT NULL,
  PRIMARY KEY (`id_visit`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;

INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (1, 126, 1, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (2, 127, 1, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (3, 125, 1, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (4, 126, 6, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (5, 125, 6, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (6, 126, 1, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (7, 126, 6, 2018-11-18);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (8, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (9, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (10, 128, 7, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (11, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (12, 128, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (13, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (14, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (15, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (16, 129, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (17, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (18, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (19, 129, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (20, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (21, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (22, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (23, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (24, 125, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (25, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (26, 128, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (27, 125, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (28, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (29, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (30, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (31, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (32, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (33, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (34, 128, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (35, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (36, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (37, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (38, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (39, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (40, 128, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (41, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (42, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (43, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (44, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (45, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (46, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (47, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (48, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (49, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (50, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (51, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (52, 126, 6, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (53, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (54, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (55, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (56, 125, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (57, 127, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (58, 126, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (59, 129, 24, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (60, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (61, 128, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (62, 142, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (63, 126, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (64, 142, 1, 2018-11-19);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (65, 145, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (66, 143, 6, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (67, 129, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (68, 129, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (69, 129, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (70, 129, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (71, 129, 6, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (72, 129, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (73, 129, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (74, 129, 6, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (75, 129, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (76, 142, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (77, 129, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (78, 143, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (79, 142, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (80, 146, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (81, 147, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (82, 148, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (83, 149, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (84, 150, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (85, 151, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (86, 152, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (87, 153, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (88, 154, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (89, 155, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (90, 156, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (91, 157, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (92, 158, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (93, 159, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (94, 160, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (95, 161, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (96, 165, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (97, 163, 6, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (98, 165, 24, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (99, 166, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (100, 168, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (101, 168, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (102, 151, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (103, 173, 1, 2018-11-20);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (104, 165, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (105, 165, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (106, 168, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (107, 168, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (108, 218, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (109, 219, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (110, 220, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (111, 168, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (112, 168, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (113, 168, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (114, 221, 6, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (115, 222, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (116, 223, 1, 2018-11-21);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (117, 2, 1, 2018-11-26);
INSERT INTO `visitor_file` (`id_visit`, `id_file`, `id_user`, `time_visit`) VALUES (118, 3, 1, 2018-11-26);


